/*
 * Filename: teststrToLong.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Test to Converts the string that is passed in the a long. 
 *              Checks if
 *              string can be converted
 * Date: January 24, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */


#include "pa1.h"
#include "test.h"


/*
 * Long strToLong( char *str, int base );
 *
 * Return the number value of the string if the string can be converted
 * Return error for numbers that can not be converted
 */

void
teststrToLong()
{
    printf( "testing strToLong()\n" );

    TEST( strToLong("1", 10) == 1 );         /*test case of an odd number*/

    TEST( strToLong("2", 10) == 2 );         /*test case of an even number*/

    TEST( strToLong("-123", 10) == -123 );   /*test of an negative number*/

    strToLong("abc", 10);              /*test of the wrong strings*/
    TEST( errno != 0);

    strToLong("abc123", 10);           /*test string with numbers*/
    TEST( errno != 0);

    strToLong("999999999999999999", 10);    /*test high numbers*/
    TEST( errno != 0);

    strToLong("123abc", 10);             /*test numbers with string*/
    TEST( errno != 0);

    TEST( strToLong("111", 16) == 273);  /*test hexadecimal numbers*/
    strToLong("8888888888888888", 16);
    TEST( errno != 0);

    TEST( strToLong("111", 8) == 73);    /*test octal numbers*/
    strToLong("7777777777777777", 8);
    TEST( errno != 0);

    TEST( strToLong("111", 2) == 7);     /*test binary numbers*/
    strToLong("11111111111111111111111111111111111111", 2);
    TEST( errno != 0);

    printf( "Finished running tests on strToLong()\n" );
}

int
main()
{
    teststrToLong();

    return 0;
}
