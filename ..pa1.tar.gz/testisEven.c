/*
 * Filename: testisEven.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Converts the string that is passed in the a long. Checks if
 *              string can be converted
 * Date: January 24, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */



#include "pa1.h"
#include "test.h"

/*
 * int isEven( long num );
 *
 * Returns 0 to indicate false, that the number passed in is not even
 * Returns non-zero if the number passed in is even
 */

void
testisEven()
{
    printf( "testing isEven()\n" );

    TEST( isEven(500) == 1);
    TEST( isEven(5) == 0);
    TEST( isEven(2) == 1);
    TEST( isEven(0) == 1);               

    printf( "Finished running tests on isEven()\n" );
}

int
main()
{
    testisEven();

    return 0;
}
