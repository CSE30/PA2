/*
 * Filename: strToLong.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Converts the string that is passed in the a long. Checks if
 *              string can be converted
 * Date: January 24, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */

#include <stdio.h>
#include <stdlib.h>
#include "pa1.h"
#include <errno.h>

/*
 * Function name: strToLong();
 * Function prototype: long strToLong( char *str, int base )
 * Description: Converts the strings into integers using the Standard
 *              C Library routine strtol(). Returns the integer as long
 *              or error if string cannot be converted
 * Parameters:
 *      arg1: char *str -- string from command line to convert to number.
 *      arg2: int base -- the base convert the number in.
 * Side Effects: None.
 * Error Conditions: Checks if arg1 is too large to be converted.
 *                   Checks if arg1 is not a number
 * Return Value: long int indicating arg1 has been converted to a number
 */

long
strToLong( char *str, int base )
{
  char *endptr;
  long num;


  errno = 0;                           
  num = strtol(str, &endptr, base);

  /* Display message for when actually converting*/
  if( errno != 0)
  {
    char errMsg[BUFSIZ];
    (void)snprintf(errMsg, BUFSIZ,
        "\n        Converting \"%s\" base \"%d\"", str, base);
    perror(errMsg);
    return errno;
  }

  else if( *endptr != '\0')
  {
    errno = 1;
    fprintf(stderr, "\n        \"%s\" is not an integer\n", str);
    return errno;
  }

  return num;
}
