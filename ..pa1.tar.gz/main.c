/*
 * Filename: main.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Main program for the actual displaying of the desired
 *              X, displays usage and other error messages. Calls all 
 *              other modules and uses their methods
 * Date: January 24, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */


#include <stdio.h>
#include <errno.h>
#include "pa1.h"
#include <stdlib.h>

/*
 * Function name: main()
 * Function prototype: int main( int argc, char *argv[] );
 *                             or
 *                     int main( void ); if no command line processing.
 * Description: C main driver which calls C and SPARC assembly routines
 *              to output a X with user-defined parameters to the screen.
 * Parameters: X_char       : The X_char of the box surrounding the X.
 *             size        : The size of the box surrounding the X.
 *             border_char  : The character to surround the X with.
 *             filler_char : The character to fill the X with.
 * Side Effects: Outputs a X filled with X_char of user
 *               specified character surrounded by a user specified
 *               border_char in a box with dimensions X_char x size.
 * Error Conditions: None.
 * Return value: 0 for success.
 */

int
main( int argc, char *argv[] ) {
    // Make a long for each of the 4 parameters described above.
    long size, X_char, border_ch, X_ch;

       /*Print out usage message if not enough args*/
    if ( argc != 5 ){
        char* usage =
            "\nUsage: %s size X_char border_ch X_ch\n"
            "    X_size     (must be within the range of [%d - %d])\n"
                           "(must be even)\n"
            "    X_char     (must be an ASCII value within the range of [%d - %d])\n"
            "    filler_char  (must be an ASCII value within the range [%d - %d])\n"
            "               (must be different than X_ch)\n"
            "    border_char (must be an ASCII value within the range [%d - %d])\n"
            "               (must be different than border_ch)\n"
            "\n";

        (void) fprintf(stderr, usage, argv[0], X_SIZE_MIN, X_SIZE_MAX, X_SIZE_MIN,
                X_SIZE_MAX, ASCII_MIN + 1, ASCII_MAX, ASCII_MIN + 1,
                ASCII_MAX);

        return 0;
    }

    size = strToLong(argv[1], BASE);
    if (errno == 0){


        // Check if in range, or send to stderr
        if(checkRange(size, X_SIZE_MIN, X_SIZE_MAX) == 0){
            (void) fprintf(stderr,
                    "\n\tsize(%ld) must be within the range of [%d - %d]\n",
                    size, X_SIZE_MIN, X_SIZE_MAX);
        }

        /* Determine if size is an even number */
        if (isEven(size) == 0){
            (void) fprintf(stderr,
                    "\n\tX_size(%ld) must be even\n",
                    size);
        }
    }
  

    /*Check if x_char in proper range*/
    X_char = strToLong(argv[2], BASE);
    if (errno == 0){
        // Check if X_char is in range
        if(checkRange(X_char, X_SIZE_MIN, X_SIZE_MAX) == 0){

            (void) fprintf(stderr,
                "\n\tX_char(%ld) must be an ASCII in the range of [%d - %d]\n",
                    X_char, X_SIZE_MIN, X_SIZE_MAX);
        }
           }
    

    /*Check border_ch*/
    border_ch = strToLong(argv[3], BASE);
    if(errno == 0){
        // Check if border_ch is in ASCII range
        if(checkRange(border_ch, ASCII_MIN + 1, ASCII_MAX) == 0){
            (void) fprintf(stderr,
                    "\n\tborder_ch(%ld) must be an ASCII code "
                    "in the range [%d - %d]\n",
                    border_ch, ASCII_MIN + 1, ASCII_MAX);
        }
    }
   

    /*Check X_ch*/
    X_ch = strToLong(argv[4], BASE);
    if(errno == 0){
        // Check if X_ch is in ASCII range
        if(checkRange(X_ch, ASCII_MIN + 1, ASCII_MAX) == 0){
            (void) fprintf(stderr,
                    "\n\tX_ch(%ld) must be an ASCII code "
                    "in the range [%d - %d]\n",
                    X_ch, ASCII_MIN + 1, ASCII_MAX);
        }


        // Check to see that X_ch is not the same as border_ch
        if(X_ch == border_ch  == 0){
            (void) fprintf(stderr,
                    "\n\tborder_ch(%ld) and X_ch(%ld) must be "
                    "different\n",
                    border_ch, X_ch);
        }
    }

    /* Finall display X if no other issues are found in the atguments*/
    if(errno == 0)
        displayX(size, X_char, border_ch, X_ch);
    else 
        printf("%c", '\n');

    return 0;
}

