
/*
 * Filename: pa0.h
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Function prototypes and defines for pa0
 * Date: January 11, 2014
 * Sources of help: Handout, lecture, discussion
 *
 */

#ifndef PA0_H
#define PA0_H

#define EXPECTED_ARGS 1

/* User-defined types used in PA0 */

struct DueDate
{
    char *month;
    unsigned int day;
    unsigned int year;
};

/* Function prototypes for the C and assembly routines used in PA0 */

void printDueDate( const struct DueDate *dueDate );
void printWelcome( const char *string );

int squareNum( int num );

#endif /* PAO_H */

