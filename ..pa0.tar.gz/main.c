/*
 * Filename: main.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Example C routine to print out the due date info
 *              using a pointer to a structure called from MAIN()
 * Date: January 11, 2014
 * Sources of help: Handout, lecture, discussion
 *
 */


/*
 * Header files included here.
 * Std C Lib header first, then local headers.
 */

/* Standard C Library headers use angle brackets <> */
#include <stdio.h>
#include <stdlib.h>

/* Local headers use double quotes "" */
#include "pa0.h"
#include "strings.h"

/*
 * Function name: main()
 * Function prototype: int main( int argc, char *argv[] );
 *                              or
 *                     int main ( void ); if no command line processing.
 * Description: C main driver which calls C and SPARC assembly routines to 
 *              print a greeting with the student's name and birthday and 
 *              summing three ints.
 * Parameters: int containing the number to square
 * Side Effects: Outputs greeting with student's name, birthday, and the 
 *               sum of three ints.
 * Error Conditions: None.
 * Return Value: 0 indicating successful execution.
 */


int main( int argc, char *argv[] )
{
    struct DueDate dueDate;
    int argVal;
 
    /*
     * We decrement argc because the name of the program is the first 
     * argument which we do not want to count.
     */
    --argc;

    if ( argc != EXPECTED_ARGS ) {
        /* Error messages are printed to stderr */
        (void) fprintf(
                stderr,
                argc < EXPECTED_ARGS ? STR_ERR_MISSING_ARG : STR_ERR_EXTRA_ARG,
                argv[0] );

        (void) fprintf( stderr, STR_ERR_USAGE, argv[0] );

        return EXIT_FAILURE;
    }
  
    /*
     *  strtol() offers error checking/handling. See man strol
     */

    argVal = atol( argv[1] );

    dueDate.day = 15;
    dueDate.year =  2014;
    dueDate.month = "January";

    /*
     * Print the greeting message
     */
    printWelcome( STR_WELCOME );

    /*
     *  Print assignment due date
     *  print DUEDate() takes a pointer to the DUEDate struct
     */
    printDueDate( &dueDate );

    /*
     * Now square the input and print the result
     */

    (void) printf( STR_SQUARENUM, argVal, squareNum(argVal));
    
    return EXIT_SUCCESS;
}
            
