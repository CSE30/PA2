
#include <stdio.h>
#include "pa0.h"
#include "strings.h"

/*
 * Function name: printDueDate()
 * Function prototype:
 *    void printDueDate( const struct DueDate *dueDate);
 * Description: Prints to stdout the month, day, and year members of a 
 *              struct duehDate node.
 * Parameters:
 *      arg1: struct DUEDate *dueDate --pointer to the
 *            DueDate struct which should be printed.
 * Side Effects: Outputs the student's birthday info.
 * Error conditions: Checks to make sure arg1 is not NULL.
 *                   No checks to ensure struct data are correct type/values.
 * Return Value: None.
 */


void printDueDate( const struct DueDate *dueDate )
{
    if ( dueDate != NULL )
        (void) printf( STR_DUEDATE, 
                        dueDate->month,
                        dueDate->day,
                        dueDate->year );
}
