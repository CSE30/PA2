/*
 * Filename: strings.h
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Strings used in PA0 output
 * Date: January 11, 2014
 * Sources of help: Handout, lecture, discussion
 *
 */


#ifndef STRINGS_H
#define STRINGS_H

/*
 * Normal output messages
 */

#define STR_WELCOME "Welcome to CSE 30\n"
#define STR_DUEDATE "PA0 is due on %s %d, %d\n"
#define STR_SQUARENUM "The square of %d is %d\n"

/*
 * Error message
 */

#define STR_ERR_USAGE        "Usage: %s [INTEGER]\n  Integer value to square\n"
#define STR_ERR_MISSING_ARG  "%s: missing integer arg\n"
#define STR_ERR_EXTRA_ARG    "%s: too many arguments\n"

#endif /* STRINGS_H */

