/*
 * Filename: getKeys.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: gets the keys from the command line input 
 * Date: February 6, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */

#include <stdlib.h>

void getKeys( unsigned long keys[] )
{
    if (keys != NULL)
    return;
}


