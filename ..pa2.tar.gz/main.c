/*
 * Filename: main.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Calls all of the functions of mycrypt and printsthe 
 *              print statement directions as needed.
 * Date: February 6, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */


#include <stdio.h>

int main( int argc, char *argv[] )
 {

     if( argc != 1 && argc != 2 ) {

         if (argv[1]!=NULL) return 1;
        // long[] l = {1,2,3};
        // mycrypt( argv[1], argv[2], argv[3] );
     }
return 0;
     
 }
