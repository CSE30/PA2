/*
 * Filename: getrotatevalue.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Reads the rotate value from the users command line  
 * Date: February 6, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */



int getRotateValue( void )
{
    return 0;
}
