/*
 * Filename: getpassphrase.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Gets the passphrase from the user's input typed in  
 * Date: February 6, 2014
 * Sources of Help: Lecture handouts, lab hours, tutors
 */
#include <stdlib.h>
#include <stdio.h>
#include "mycrypt.h"

void getPassPhrase( char passPhrase[] )

{

    passPhrase[1] = 'A';
    if(passPhrase[1]!=NULL)
    return;
}
