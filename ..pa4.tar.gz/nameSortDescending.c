/*
 * Filename: nameSortDescending.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Sort name field in descending order
 * Sources of Help: Lab Hours, discussion section, tutors
 */


#include "mywho.h" 
#include <string.h>

int
nameSortDescending( const void *ptr1, const void *ptr2 ){
    
    struct utmpInfo* fiptr1 = (struct utmpInfo*) ptr1;
    struct utmpInfo* fiptr2 = (struct utmpInfo*) ptr2;

    return -1 * strcmp(fiptr1->user, fiptr2->user);  //Ret inverse of strcmp
}
