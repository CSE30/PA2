/*
 * Filename: pa4time.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Calcuates time in time_t format and returns for printing
 * Sources of Help: Lab Hours, discussion section, tutors
 */


#include <sys/types.h>
#include <time.h>
#include <stdio.h>

time_t pa4time( time_t *t )
{

    time_t retval = time( 0 );
        
    if ( t != NULL )
    {
      *t = retval;
    }

    return retval;
}
