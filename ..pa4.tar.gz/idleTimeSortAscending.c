/*
 * Filename: idleTimeSortAscending.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: sort the idle time in increasing order
 * Sources of Help: Lab Hours, discussion section, tutors
 */


#include "mywho.h"


int idleTimeSortAscending(const void *p1, const void *p2)
{
  struct utmpInfo * Ptr1 = (struct utmpInfo *)p1;
  struct utmpInfo * Ptr2 = (struct utmpInfo *)p2;

  if((Ptr1->idle) < (Ptr2->idle))  return -1; //If 2 > 1
  

  else if((Ptr1->idle) == (Ptr2->idle))  return 0;  //If equal
  
  else  return 1;  //If 1> 2
  
}
