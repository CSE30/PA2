/*
 * Filename: buildUtmpInfoTable.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: With input utmp file, creates a database holding the 
 *              information needed to be printed by mywho
 * Sources of Help: Lab Hours, discussion section, tutors
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include "mywho.h"
#include "strings.h"


int buildUtmpInfoTable( const char *utmpFilename,
                        struct utmpInfo **utmpInfoPtr ){
    
    
    FILE *fileIn; //Open file
    char errMessage[BUFSIZ]; //error message
    struct utmpx temp;
    struct utmpInfo *utmpInfoAlloc;
    struct utmpInfo *tempAlloc = NULL;
    time_t curTime; //current time
    int count = 0;
    int host_length;


    /*Open file and print necessary strings*/
    if( (fileIn = fopen(utmpFilename, "r") ) == NULL){
        (void) snprintf (errMessage, BUFSIZ, FOPEN_ERR, utmpFilename );
        perror(errMessage);
        exit(EXIT_FAILURE);
    }
    
    /*Read first input*/
    (void)fread(&temp, 1, sizeof(struct utmpx), fileIn);
    
    /*Check if valid utmpx*/
    if(strcmp(temp.ut_line, DOWN_MSG)){
        (void)fprintf(stderr, FILE_NOT_UTMPX, utmpFilename);
        (void)fclose(fileIn);
        exit(EXIT_FAILURE);
    }

    else rewind(fileIn);

    
    (void) memset(&temp, 0, sizeof(struct utmpx));
    (void) memset(&curTime, 0, sizeof(time_t));

    /*Keep reading through the utmpx*/
    while(fread(&temp, 1, sizeof(struct utmpx), fileIn)){
        count++;
        
        //allocating utmpInfo array
        utmpInfoAlloc = (struct utmpInfo *)realloc(tempAlloc,
                         count*sizeof(struct utmpInfo));
        
        if(!utmpInfoAlloc){
            perror(REALLOC_ERR);
            return count;
        }else{
            tempAlloc = utmpInfoAlloc;
        }
        
        /*Print the information for each member*/
        (void)strcpy(tempAlloc[count-1].user, temp.ut_user);
        
        (void)strcpy(tempAlloc[count-1].line, DEV_FMT);

        (void)strcat(tempAlloc[count-1].line, temp.ut_line);
        
        tempAlloc[count-1].pid  = temp.ut_pid;
        tempAlloc[count-1].type = temp.ut_type;
        tempAlloc[count-1].time = temp.ut_tv.tv_sec;
        host_length = strlen(temp.ut_host);
        tempAlloc[count-1].host = (char*)calloc(host_length+1,
                                                    sizeof(char));
        (void)memcpy(tempAlloc[count-1].host, temp.ut_host,
                     host_length+1);
                
        tempAlloc[count-1].idle = curTime;
       
        //Reset mem again after looping through
        (void) memset(&temp, 0, sizeof(struct utmpx));
        (void) memset(&curTime, 0, sizeof(time_t));
        
    }

    *utmpInfoPtr = tempAlloc; //Reset pointer
    (void)fclose(fileIn); //Close file
    return count;
}
