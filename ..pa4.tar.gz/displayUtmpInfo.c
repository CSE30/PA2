#include "mywho.h"
#include <stdlib.h>
#include <sys/mkdev.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include "strings.h"
#include <errno.h>

/*
 * Function name: displayUtmpInfo()
 * Function prototype: void displayUtmpInfo( struct utmpInfo * const table,
 *                     const int entries, const int displayMode )
 * Description: Displays information on a set of files contained in an array
 *              of utmpInfo structs given the following options:
 *              -a: All files are displayed (including those starting with '.'
 *              -l: Files are displayed in long listed format.
 *              -r: Files are displayed in reverse order.
 *              -t: Instead of name order, use modified time order.
 * Parameters:
 *     table: the array of utmpInfo structs to read from
 *     entries: number of elements in table.
 *     displayMode: an integer that determines how the info is displayed
 * Side Effects: Will print out information in table in the specified format
 *               to stdout.
 * Error Conditions: None.
 * Return value: None.
 */

void
displayUtmpInfo( struct utmpInfo * const table, const int entries,
                      const int displayMode )
{
    char displayTime[BUFSIZ];//to display, formatted string
    struct tm *loctime; //for loctime ret
    struct utmpInfo *searchResult; //search result
    int i;//traversal count;
    int row = 0;//count for 8 users /row
    int numOfUser = 0; //number of users online

    //Executing based on displayMode
    if(displayMode & Q_FLAG){//-q
          if(displayMode){
              if(errno){
                 (void)fprintf(stderr, USAGE_FMT, programName, SHORT_USAGE);
                  exit(EXIT_FAILURE);
              }
          }
          numOfUser = 0;
          for(i = 0; i<entries; i++){
              if(table[i].type == USER_PROCESS){
                  numOfUser++;
                  row++;
                     (void)fprintf(stdout, USER_NAME_FMT,
                           table[i].user, '\n');
                     row = 0;
                  }
                  else
                     (void)fprintf(stdout, USER_NAME_FMT,
                               table[i].user, ' ' );
              }
          }
         
        

      if(displayMode & H_FLAG){//-H
          if(displayMode)
              (void)fprintf(stdout, HEADER_FMT, LONG_HEADER);
          else
              (void)fprintf(stdout, HEADER_FMT, HEADER);
        }

        if(displayMode & B_FLAG){//-B
            //get localtime
            loctime = localtime(&table[1].time);
            //format string
            if(!strftime(displayTime, BUFSIZ, STRFTIME_FMT, loctime)){
                (void)fprintf(stderr, STRFTIME_ERR);
                exit(EXIT_FAILURE);
            }
        }


        if(displayMode & S_FLAG){//-S
              (void)qsort(table, entries, sizeof(struct utmpInfo), nameSortAscending);
              searchResult = (struct utmpInfo*)bsearch(optarg, table, entries,
                                                     sizeof(struct utmpInfo),
                                                     nameSortAscending);
              if(!searchResult){
                  (void)fprintf(stderr, USER_NOT_FOUND_ERR, optarg);
              }
              else{
                  //traverse left
                  while(searchResult != (table-1) && searchResult != (table+entries)
                      && !strcmp(searchResult->user, optarg))
                      searchResult--;
                  searchResult++;// revert back

                  //traverse right and printing
                  while(searchResult != (table-1) && searchResult !=(table+entries)
                         && !strcmp(searchResult->user, optarg)){
                      if(searchResult->type == USER_PROCESS){
                         calcIdleTime(searchResult->idle, displayTime, BUFSIZ);
                         (void)fprintf(stdout, LONG_DISPLAY_FMT, searchResult->user,
                                    ' ', searchResult->line,
                                    displayTime, searchResult->host);
                      }
                      searchResult++;
                  }
              }
              return;
          }

          if(displayMode & SORT_BY_IDLE_FLAG){//-i
              if(!(displayMode & R_FLAG))//check if reverse sort selected
                 (void)qsort(table, entries, sizeof(struct utmpInfo),
                             idleTimeSortAscending);
              else
                  (void)qsort(table, entries, sizeof(struct utmpInfo),
                              idleTimeSortDescending);

          }
          //display data after options processing
             for(i = 0; i<entries; i++){
                 if(table[i].type == USER_PROCESS){
                    calcIdleTime(table[i].idle, displayTime, BUFSIZ);
                    (void)fprintf(stdout, LONG_DISPLAY_FMT, table[i].user,
                               ' ', table[i].line, displayTime,
                               table[i].host);
                 }
             }


             return;
}


