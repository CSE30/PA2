/*
 * Filename: mywho.c
 * Author: Ricardo Ambriz
 * Userid: cs30xaf
 * Description: Determines which cases are being called upon by the user
 *              prints all error messages and gathers the info to print
 * Sources of Help: Lab Hours, discussion section, tutors
 */


#include "mywho.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include "strings.h"

int
main( int argc, char* argv[] ){

    int count; 
    char *filename;  //Utmp file passed in
    struct utmpInfo *utmpArray; //Utmp info built

	   

    /* Cycle through options, determine which ones selected */
    int displayMode = 0; //Mode to be displayed
    int option; 
    while((option = getopt(argc, argv, GETOPT_OPTIONS)) != -1){
        switch(option){
        case 'h': //help message.
            displayMode = (displayMode | HELP_FLAG);
            break;
        case 'B': //Boot time.
            displayMode = (displayMode | B_FLAG);
            break;
        case 'H': //Print header.
            displayMode = (displayMode | H_FLAG);
            break;
        case 'q': //Quick mywho.
            displayMode = (displayMode | Q_FLAG);
            break;
        case 'r': //Boot time.
            displayMode = (displayMode | R_FLAG);
            break;
         case 's': //Print header.
            displayMode = (displayMode | S_FLAG);
            break;
         case 'i': //Quick mywho.
            displayMode = (displayMode | SORT_BY_IDLE_FLAG);
            break;
         case 'u': //help message.
            displayMode = (displayMode | SORT_BY_USER_FLAG);
            break;

        default: // Anything outside of opts
        	(void)fprintf(stderr, USAGE_FMT, argv[0],
                          SHORT_USAGE);
        	exit(EXIT_FAILURE);  // Illegal input
        }
    }


    //If no file passed in
      if(optind != argc){
           filename = argv[argc-1];
       }

       //Print error messages
       else{
           (void)fprintf(stderr, USAGE_FMT, argv[0], SHORT_USAGE); 
           return EXIT_FAILURE;
       }
           
    
       //Update the info counter passed in
       count = buildUtmpInfoTable(filename, &utmpArray);
       
       displayUtmpInfo(utmpArray, count, displayMode);

       int i;
       for( i = 0; i < count; i++)
           free(utmpArray[i].host);   //Free host name
       

       free(utmpArray);  //Free built table info
       
       return EXIT_SUCCESS;  //SUCCESS!!
   }
