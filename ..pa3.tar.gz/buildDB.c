/*
 * Filename: buildDB.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Builds the database of sorted words using an input source
 *              and writes these sorted db to a seperate out file
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "anagrams.h"

/*
 * Function name: buildDB
 * Function prototype: void buildDB ( const char *const dictFilename );
 * Description:
 * Parameters: dictFilename - the file to read in.
 * Side Effects: Builds a file anagramsDB with the inputed words sorted by
 *               their char values
 * Return value: None.
 */

void
buildDB( const char *const dictFilename ){
    
    
    //Local variables 
    FILE *inFilePtr, *outFilePtr;
    char charArray[SIZE] = {"0"};
    struct anagram anaStruct;

    errno = 0;
    if ( (inFilePtr = fopen(dictFilename, "r")) == NULL ){
        perror(dictFilename);
        exit(EXIT_FAILURE);
    }

    errno = 0;
    if ( (outFilePtr = fopen(anagramsDB, "wb")) == NULL ){
        perror(anagramsDB);
        exit(EXIT_FAILURE);
    }

    /*
     * Read in one word at a time to build anagramsDB
     */
    while (fgets(charArray, SIZE, inFilePtr) != NULL) {
        // Replace newline with null char.
        char *ptr = strchr(charArray, '\n');
        *ptr = '\0';
        
        (void) memset(anaStruct.word, 0, SIZE);
        (void) memset(anaStruct.sorted, 0, SIZE);
        
        (void) strncpy(anaStruct.word, charArray, SIZE);
        
        //Send all chars to lower for easy comparing
        int i;
        for (i = 0; i < strlen(charArray); i++){
            charArray[i] = (char) tolower((int) charArray[i]);
        }
       
        qsort(charArray, strlen(charArray), sizeof(char), charCompare);
        // Store sorted word into anaStruct
        (void) strncpy(anaStruct.sorted, charArray, SIZE);
        // Write to anagramsDB.dat
        if(fwrite(&anaStruct, sizeof(anaStruct), 1, outFilePtr) != 1) {
             (void) fprintf(stderr, "Whoa! Got a write error on word "
                     "\"%s\".\n", anaStruct.word);
             exit( EXIT_FAILURE ); //if program exits
        }
    }


    (void) fclose(inFilePtr);  //Close inFile
    (void) fclose(outFilePtr); //Close outfile
    (void) printf(" Anagram database file \"%s\" built.\n", anagramsDB);
}
