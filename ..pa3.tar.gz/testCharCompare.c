/*
 * Filename: testcharCompare.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Test functionality of charCompare() method 
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include "anagrams.h"
#include "test.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


void
charCompareTest()
{
    char a = 'a';
    char *a1 = &a;

    char b = 'b';
    char *b1 = &b;


    /* Test all three possible outcomes of method */
    TEST( charCompare(a1, a1) == 0 );
    TEST( charCompare(a1, b1) == -1 );
    TEST( charCompare(b1, a1) == 1 );

    (void)printf("Testing Complete!\n");
}

int
main()
{
    charCompareTest();

    return 0;
}  
