/*
 * Filename: processDB.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Processes the DB file build by the buildDB() method 
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "anagrams.h"
#include <errno.h>
#include <sys/stat.h>

/*
 * Function name: processDB (struct anagramInfo *anagramInfoPtr);
 * Function prototype: void processDB (struct anagramInfo *anagramInfoPtr);
 * Description: Processes the DB file created by buildDB()
 * Parameters: anagramInfoPtr - the pointer to anagram needed
 * Side Effects: None
 * Error Conditions: None
 * Return Value: None 
 */

void processDB(struct anagramInfo *anagramInfoPtr) {

	struct stat statStruct;

    //Counter variables
	int sizeOfFile;
	int numOfAnagrams;
	int numOfValues;

	//Error checking if stat fails
    if (stat(anagramsDB, &statStruct) != 0) {
		perror("Stat failed on anagram database file");
		(void)fprintf(stderr,
		"May need to run \"anagrams --build dictionary_file\" first.\n");
		exit(EXIT_FAILURE);
	}

	sizeOfFile = statStruct.st_size;


	numOfAnagrams = sizeOfFile / sizeof(struct anagram); //Number of anagrams
	anagramInfoPtr->numOfAnagrams = numOfAnagrams;
	anagramInfoPtr->anagramPtr = (struct anagram *) calloc(
			numOfAnagrams, sizeof(struct anagram));

    //Error checking if anagramptr is null object
	if (anagramInfoPtr->anagramPtr == NULL ) {
		perror("Trying to calloc() anagram data structure in memory");
		exit(EXIT_FAILURE);
	}

	
	FILE *inFilePtr; //Open files

    //Error check if null
	if ((inFilePtr = fopen(anagramsDB, "r")) == NULL ) {
		perror(anagramsDB);
		exit(EXIT_FAILURE);
	}

	
	numOfValues = fread(anagramInfoPtr->anagramPtr,
			sizeof(struct anagram), numOfAnagrams, inFilePtr); //Number of values

	
    if (numOfValues != numOfAnagrams) {
		(void)fprintf(stderr,
		"Error with fread() of anagram data.\nExpecting %d; got %d.\n",
		numOfAnagrams, numOfValues);
	}

	
    //Sort the final value of the arguments passed in
	qsort(anagramInfoPtr->anagramPtr, numOfAnagrams,
			sizeof(struct anagram), anagramCompare);

}

