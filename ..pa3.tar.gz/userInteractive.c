/*
 * Filename: userInteractive.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Userinteractive interacts with the inputs put in by the user
 *              calls the required searches to look for the strings being
 *              inputted and prints them if found, prompts user for more
 *              inquiries.
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "anagrams.h"

/*
 * Function name: userInteractive()
 * Function prototype:
 *    void userInteractive( struct anagramInfo *anagramInfoPtr );
 * Description: Process the input of the user and determines if their
 *              input is in the database and calls functions as well
 *              as prints messages to the user
 * Side Effects: Outputs anagrams of the user provided word to stdout.
 * Error Conditions: 
 * Return Value: None
 */
void userInteractive( struct anagramInfo *anagramInfoPtr )
{
  char charArray[SIZE];
  struct anagram anaStruct;
  struct anagram *anaStructPtr;
  struct anagram *anaNext;
  char *replace = NULL;
  int i;

  (void) printf("%s", 
          "\nEnter a word to search for anagrams [^D to exit]: ");

  //Find string in array
  while( fgets(charArray, SIZE, stdin) )
  { 
    replace = strchr(charArray, '\n');
    *replace = '\0';
    //Make sure fields are empty
    (void) memset(anaStruct.word, 0, SIZE);
    (void) memset(anaStruct.sorted, 0, SIZE);
    (void) strcpy(anaStruct.word, charArray);

    //Send whole string to lower case
    for(i = 0; charArray[i]; i++)
    {
      charArray[i] = tolower( charArray[i] );
    }

    //Sort the lowercase string
    qsort(charArray, strlen(charArray), sizeof(char), charCompare);

    (void) strcpy(anaStruct.sorted, charArray);
    anaStructPtr = (struct anagram*) bsearch(&anaStruct,
        anagramInfoPtr->anagramPtr,
        anagramInfoPtr->numOfAnagrams,
        sizeof(struct anagram),
        sortedMemberCompare);

    //If anagram lloking for does not exist
    if(anaStructPtr != NULL)
    {
      anaNext = anaStructPtr;

      //Keep searching next pointer for the input
      while(anaNext != NULL)
      {
        if( strcmp(anaNext->sorted, anaStructPtr->sorted) == 0 )
          anaNext--;
        else
          break;
      }
      
      anaNext++;
      (void) printf("Anagram(s) are:");  //For anagrams that are found

      //Keep searching through array and print when ever it finds one
      while(anaNext != NULL)
      {
        if( strcmp(anaNext->sorted, anaStructPtr->sorted) == 0 )
        {
          (void) printf(" %s", anaNext->word);
          anaNext++;
        }
        else
          break;
      }
      (void) printf("\n"); //New line after every iteration
    }
    else
      (void) fprintf(stderr, "%s", "No anagrams found.\n");

    //Back at the top
    (void) printf("%s", 
            "\nEnter a word to search for anagrams [^D to exit]: "); 
  } 
}
