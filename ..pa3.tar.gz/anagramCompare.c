/*
 * Filename: anagramCompare.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Compares two anagrams to see if words are the same
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include "anagrams.h"
#include <string.h>
#include <stdlib.h>

/*
 * Function name: anagramCompare()
 * Function prototype: int anagramCompare(const void *ptr1, const void *ptr2); 
 * Description: Function compares two anagrams checks if the chars are same
 * Parameters: arg 1 - const void *ptr1
 *             arg 2 - const void *ptr2
 * Side Effects: None.
 * Error Conditions: None.
 * Return Value: An int more or less than 0
 */


int
anagramCompare(const void *ptr1, const void *ptr2)
{
    
    //Compare the two anagram ptrs being passed in in the arguments
    struct anagram *ptrOne = (struct anagram *)ptr1;
    struct anagram *ptrTwo = (struct anagram *)ptr2;

    //Return true or false, in ints depending on equality
    if (strcmp(ptrOne->sorted, ptrTwo->sorted) == 0) 
    {
        return (strcmp(ptrOne->word, ptrTwo->word));    
    }
    else 
    { 
        return (strcmp(ptrOne->sorted, ptrTwo->sorted));
    }    
}
