/*
 * Filename: anagram.h
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Contains all the header methods and method prototypes
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#ifndef anagrams	/* Macro Guard */
#define anagrams

/*
 * Use in building and processing DB.
 */

#define SIZE 80
#define anagramsDB "anagrams.dat"


/**
 * Use in for loop for userInteractive.
 */

#define DISPLAY_PROMPT (void) printf( PROMPT )
#define PROMPT "\nEnter a word to search for anagrams [^D to exit]: "

/**
 * Usable Structs
 */

struct anagram {
    char word[SIZE];
    char sorted[SIZE];
};

struct anagramInfo {
    struct anagram *anagramPtr;
    int numOfAnagrams;
};


/*
 * Local function prototypes for PA3 written in C
 */

void buildDB ( const char *const dbFilename );
void processDB( struct anagramInfo *anagramInfoPtr );
void userInteractive( struct anagramInfo *anagramInfoPtr );
int anagramCompare( const void *ptr1, const void *ptr2 );
int sortedMemberCompare( const void *ptr1, const void *ptr2);

/*
 * Local function prototypes for PA3 written in Assembly
 */

int charCompare( const void *ptr1, const void *ptr2 );

#endif /* anagrams */
