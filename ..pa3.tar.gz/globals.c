/*
 * Filename: globals.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Global header file containing libraries and stderr file
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */
 

/*
    
  * C file to define global variables across C and Assembly
    
  */
    
 #include <stdio.h>
    
 FILE *stdError = stderr;
