/*
 * Filename: sortedMemberCompare.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Compares if two anagrams sorted fields are greater or lessthan
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include "anagrams.h"
#include <string.h>

/*
 * Function name: sortedMemberCompare
 * Function prototype:
 *     int sortedMemberCompare( const void *ptr1, const void *ptr2);
 * Description: Compares to anagrams after their fields have been sorted
 * Parameters:
 *     ptr1: struct anagram
 *     ptr2: struct anagram
 * Side Effects: None.
 */

int sortedMemberCompare( const void *ptr1, const void *ptr2 ){
    struct anagram* anagram1 = (struct anagram*) ptr1;
    struct anagram* anagram2 = (struct anagram*) ptr2;
    return strcmp(anagram1->sorted, anagram2->sorted);
}
