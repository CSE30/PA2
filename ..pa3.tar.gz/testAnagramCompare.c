/*
 * Filename: testanagramCompare.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description: Test functionality of anagramCompare() method 
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */

#include "anagrams.h"	
#include "test.h"	    
#include <string.h>


void
testAnagramCompare()
{
    
    printf( "Testing anagramCompare()\n" );

    /* Compare and modify these two anagrams to test*/
    struct anagram ana1;
    struct anagram ana2;

    (void)strncpy(ana1.word, "xyz" ,  80);
    (void)strncpy(ana1.sorted, "xyz" ,  80);
    (void)strncpy(ana2.word, "xyz" ,  80);
    (void)strncpy(ana2.sorted, "xyz" ,  80);
    TEST( anagramCompare( &ana1, &ana2 ) == 0 );

    (void)strncpy(ana1.word, "xyz" ,  80);
    (void)strncpy(ana1.sorted, "aa" ,  80);
    (void)strncpy(ana2.word, "xx" ,  80);
    (void)strncpy(ana2.sorted, "yy" ,  80);
    TEST( anagramCompare( &ana1, &ana2 ) != 0 );

    //First leter caps
    (void)strncpy(ana1.word, "Abc" ,  80);
    (void)strncpy(ana1.sorted, "Acc" ,  80);
    (void)strncpy(ana2.word, "Acd" ,  80);
    (void)strncpy(ana2.sorted, "Add" ,  80);
    TEST( anagramCompare( &ana1, &ana2 ) != 0 );

    printf( "Testing Complete!\n" );

}

int
main()
{
    //Run tests
    testAnagramCompare();

    return 0;
}
