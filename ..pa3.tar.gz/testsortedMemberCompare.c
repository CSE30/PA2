/*
 * Filename: testsortedMemberCompare.c
 * Author: Ricardo Ambriz
 * Userid: cs30xdj
 * Description:Text functionality of testsortedmembercompare()  
 * Date: February 21, 2014
 * Sources of Help: Lab Hours, discussion, piazza, tutors
 */


#include "test.h"
#include "anagrams.h"

void
testsortedMemberCompare()
{
  printf( "Testing sortedMemberCompare()\n" );

  struct anagram ptr1;
  strncpy(ptr1.word, "abc", SIZE);
  strncpy(ptr1.sorted, "abc", SIZE);

  struct anagram ptr2;
  strncpy(ptr2.word, "dog", SIZE);
  strncpy(ptr2.word, "ogd", SIZE);

  //Test for greater than
  TEST( sortedMemberCompare( &ptr1, &ptr2) > 0);

  //Test for failure
  strncpy(ptr2.word, "XYZ", SIZE);
  strncpy(ptr2.sorted, "zyx", SIZE);
  TEST( sortedMemberCompare( &ptr1, &ptr2) < 0);

  //Test if in scrambled order
  strncpy(ptr2.word, "bca", SIZE);
  strncpy(ptr2.sorted, "abc", SIZE);
  TEST( sortedMemberCompare( &ptr1, &ptr2) == 0);

  printf( "Testing Complete!\n" );
}

int
main()
{
    testsortedMemberCompare();

    return 0;
}
